package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class InformationData extends AppCompatActivity {

    TextView tvChosenCourse, tvChosenInstitution, tvCourseInfor, tvSubject, tvWebsites, tvTelephone, tvDirection, tvApScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information_data);

        tvChosenCourse = findViewById(R.id.tvChosenCourse);
        tvChosenInstitution = findViewById(R.id.tvChosenInstitution);
        tvCourseInfor = findViewById(R.id.tvCourseInfor);
        tvSubject = findViewById(R.id.tvSubject);
        tvWebsites = findViewById(R.id.tvWebsites);
        tvTelephone = findViewById(R.id.tvTelephone);
        tvDirection = findViewById(R.id.tvDirection);
        tvApScore = findViewById(R.id.tvApScore);


    }
}
