package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

public class Admin extends AppCompatActivity {

    ImageView ivAdmin;
    EditText etAdminUsername, etAdminPassword;
    Button btnLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        ivAdmin = findViewById(R.id.ivAdmin);
        etAdminUsername = findViewById(R.id.etAdminUsername);
        etAdminPassword = findViewById(R.id.etAdminPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etAdminUsername.getText().toString().isEmpty() && etAdminPassword.getText().toString().isEmpty())
                {

                    Toast.makeText(Admin.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();

                }

                else
                {

                    String mail = etAdminUsername.getText().toString().trim();
                    String password = etAdminPassword.getText().toString().trim();


                    Backendless.UserService.login(mail, password, new AsyncCallback<BackendlessUser>() {
                        @Override
                        public void handleResponse(BackendlessUser response) {

                            Toast.makeText(Admin.this, "Successfully logged in.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Admin.this, com.example.myapplication.MainActivity.class);
                            startActivity(intent);


                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {

                            Toast.makeText(Admin.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }, true);






                }


            }
        });
                }
            }


