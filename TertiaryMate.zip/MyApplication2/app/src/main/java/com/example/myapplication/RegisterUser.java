package com.example.myapplication;

public class RegisterUser
{

    public String surname, names, idNumber, email, password, confirmPassword, objectId;

    public RegisterUser(String surname, String names, String idNumber, String email, String password, String confirmPassword, String objectId) {
        this.surname = surname;
        this.names = names;
        this.idNumber = idNumber;
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.objectId = objectId;

    }


    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getObjectId() {
       return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
   }
}
