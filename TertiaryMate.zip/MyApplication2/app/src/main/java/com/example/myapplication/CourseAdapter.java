package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.ViewHolder>
{

    private List<CourseClass> courseClasses;
    ItemClicked activity;


    public CourseAdapter (Context context, List<CourseClass> list)
    {
      courseClasses = list;

      activity = (ItemClicked) context;

    }


    public interface ItemClicked
    {
        void onItemClicked(int index);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvCourses;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            tvCourses = itemView.findViewById(R.id.tvCourses);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    activity.onItemClicked(courseClasses.lastIndexOf((CourseClass) view.getTag()));

                }
            });
        }
    }

    @NonNull
    @Override
    public CourseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items1, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseAdapter.ViewHolder holder, int position) {


        holder.itemView.setTag(courseClasses.get(position));
        holder.tvCourses.setText(courseClasses.get(position).getCourseName());

    }

    @Override
    public int getItemCount() {
        return courseClasses.size();
    }
}
