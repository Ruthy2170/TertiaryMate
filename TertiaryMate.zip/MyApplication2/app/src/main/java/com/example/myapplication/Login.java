package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

public class Login extends AppCompatActivity {

    ImageView ivLogo;
    TextView tvLink;
    EditText etLoginUsername, etLoginPassword;
    Button btnLogin, btnRegister, btnAdmin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        ivLogo = findViewById(R.id.ivLogo);
        etLoginUsername = findViewById(R.id.etLoginUsername);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnAdmin = findViewById(R.id.btnAdmin);
        tvLink = findViewById(R.id.tvLink);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etLoginUsername.getText().toString().isEmpty() && etLoginPassword.getText().toString().isEmpty())
                {

                    Toast.makeText(Login.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();

                }

                else

                {


                    String mail = etLoginUsername.getText().toString().trim();
                    String password = etLoginPassword.getText().toString().trim();


                    Backendless.UserService.login(mail, password, new AsyncCallback<BackendlessUser>() {
                        @Override
                        public void handleResponse(BackendlessUser response) {

                            Toast.makeText(Login.this, "Successfully logged in.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Login.this, com.example.myapplication.MainActivity.class);
                            startActivity(intent);


                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {

                            Toast.makeText(Login.this, "You are not registered yet!" + fault.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }, true);

                }

            }
        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Login.this, com.example.myapplication.Register.class);
                startActivity(intent);

            }
        });


        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Login.this, com.example.myapplication.Admin.class);
                startActivity(intent);

            }
        });


        tvLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Login.this, com.example.myapplication.ForgotPassword.class);
                startActivity(intent);

            }
        });


    }
}
