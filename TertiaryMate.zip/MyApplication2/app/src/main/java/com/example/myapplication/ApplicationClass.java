package com.example.myapplication;


import android.app.Application;

import com.backendless.Backendless;

import java.util.ArrayList;
import java.util.List;

public class ApplicationClass extends Application {

    public static final String APPLICATION_ID = "932443AB-6D32-76F6-FFC6-E872A085D400";
    public static final String API_KEY = "50D2B99C-5C26-44BD-A055-7284A6E16E54";
    public static final String SERVER_URL = "https://api.backendless.com";

    public static Backendless user;

    public static ArrayList<CourseClass> courseClasses;
    public static ArrayList<Institution> institutions;



    @Override
    public void onCreate() {
        super.onCreate();


        Backendless.setUrl( SERVER_URL );
        Backendless.initApp( getApplicationContext(),
                APPLICATION_ID,
                API_KEY );



    }
}
