package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

public class Register extends AppCompatActivity {

    ImageView ivRegister;
    EditText etRegSurname, etRegNames, etRegIdNumber, etRegEmail, etRegPassword, etRegConfirmPassword;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



        ivRegister = findViewById(R.id.ivRegister);
        etRegSurname = findViewById(R.id.etRegSurname);
        etRegNames = findViewById(R.id.etRegNames);
        etRegIdNumber = findViewById(R.id.etRegIdNumber);
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPassword);
        etRegConfirmPassword = findViewById(R.id.etRegConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etRegSurname.getText().toString().isEmpty() && etRegNames.getText().toString().isEmpty() && etRegIdNumber.getText().toString().isEmpty() &&
                        etRegEmail.getText().toString().isEmpty() && etRegPassword.getText().toString().isEmpty() && etRegConfirmPassword.getText().toString().isEmpty())
                {

                    Toast.makeText(Register.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    if(etRegPassword.getText().toString().trim().equals(etRegConfirmPassword.getText().toString().trim()))
                    {

                        String surname= etRegSurname.getText().toString().trim();
                        String name= etRegNames.getText().toString().trim();
                        String idNumber= etRegIdNumber.getText().toString().trim();
                        String email= etRegEmail.getText().toString().trim();
                        String password= etRegPassword.getText().toString().trim();
                        String confirmPassword= etRegConfirmPassword.getText().toString();

                    // RegisterUser registerUser=new RegisterUser(surname,name,idNumber,email,password,confirmPassword);

                        BackendlessUser user = new BackendlessUser();
                        String username = etRegEmail.getText().toString().trim();
                        user.setEmail(username);
                        String mPassword = etRegPassword.getText().toString().trim();
                        user.setPassword(mPassword);
                        user.setProperty("name", etRegSurname.getText().toString() );

                        Backendless.UserService.register(user, new AsyncCallback<BackendlessUser>() {
                            @Override
                            public void handleResponse(BackendlessUser response) {


                                Toast.makeText(Register.this, "User successfully registered!", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(Register.this, com.example.myapplication.Login.class);
                                startActivity(intent);


                            }

                            @Override
                            public void handleFault(BackendlessFault fault) {

                                Toast.makeText(Register.this, "Error" + fault.getMessage(), Toast.LENGTH_LONG).show();

                            }
                        });

                    }

                    else
                    {

                        Toast.makeText(Register.this, "Please make sure the passwords match!", Toast.LENGTH_SHORT).show();

                    }

                }


            }
        });

    }
}
