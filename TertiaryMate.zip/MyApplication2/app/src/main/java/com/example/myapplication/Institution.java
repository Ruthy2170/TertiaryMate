package com.example.myapplication;

import android.app.Application;

public class Institution extends Application
{

    private String universityName;

    private String objectId;

    public Institution(){}

    public Institution(String universityName) {
        this.universityName = universityName;
    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

}
