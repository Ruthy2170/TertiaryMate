package com.example.myapplication;

import android.app.Application;

public class Information extends Application {

    private String courseInfo, subjects, website, telephone, direction, objectId;
    private int apScore;

    public Information(){}

    public Information(String courseInfo, String subjects, String website, String telephone, String direction, String objectId, int apScore) {

        this.courseInfo = courseInfo;
        this.subjects = subjects;
        this.website = website;
        this.telephone = telephone;
        this.direction = direction;
        this.apScore = apScore;
        this.objectId = objectId;

    }
    public String getCourseInfo() {
        return courseInfo;
    }

    public void setCourseInfo(String courseInfo) {
        this.courseInfo = courseInfo;
    }

    public String getSubjects() {
        return subjects;
    }

    public void setSubjects(String subjects) {
        this.subjects = subjects;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public int getApScore() {
        return apScore;
    }

    public void setApScore(int apScore) {
        this.apScore = apScore;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }
}
