package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.ArrayList;
import java.util.List;

public class Universities extends AppCompatActivity implements InstitutionAdapter.ItemClicked
{

    RecyclerView recyclerView;
    RecyclerView.Adapter myAdapter;
    RecyclerView.LayoutManager layoutManager;

    EditText etNewUniversity;
    Button btnSaved;
    TextView tvPickedCourse;

    ArrayList<Institution> institutions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_universities);

        tvPickedCourse = findViewById(R.id.tvPickedCourse);
        etNewUniversity = findViewById(R.id.etNewUniversity);
        btnSaved = findViewById(R.id.btnSaved);

        recyclerView = findViewById(R.id.rvUniversity);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        String myData = getIntent().getStringExtra("index");
        tvPickedCourse.setText(myData);

        institutions = new ArrayList<Institution>();

        /*
        institutions.add(new Institution("Central University of Technology"));
        institutions.add(new Institution("University of Cape Town"));
        institutions.add(new Institution("University of Limpopo"));
        institutions.add(new Institution("Rhodes University"));
*/

        DataQueryBuilder queryBuilder = DataQueryBuilder.create();
        //queryBuilder.setWhereClause(whereClause);
        queryBuilder.setGroupBy("courseName");

        Backendless.Persistence.of(Universities.class).find(queryBuilder, new AsyncCallback<List<Universities>>() {
            @Override
            public void handleResponse(List<Universities> response) {

                myAdapter = new InstitutionAdapter(Universities.this, response);
                recyclerView.setAdapter(myAdapter);


            }

            @Override
            public void handleFault(BackendlessFault fault) {

                Toast.makeText(Universities.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });



        myAdapter = new InstitutionAdapter(this, institutions);
        recyclerView.setAdapter(myAdapter);

        btnSaved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //String newUniversity = etNewUniversity.getText().toString().trim();

                if(etNewUniversity.getText().toString().isEmpty() == false)
                {
                    Backendless.Persistence.save(ApplicationClass.institutions.get(0), new AsyncCallback<Institution>() {
                        @Override
                        public void handleResponse(Institution response) {

                            Toast.makeText(Universities.this, "New Institution successfully saved!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {

                            Toast.makeText(Universities.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });


                }
            }
        });

    }

    @Override
    public void onItemClicked(int index) {

        Intent intent = new Intent(Universities.this, InformationData.class);
        intent.putExtra("Data", index);
        startActivity(intent);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }
}
