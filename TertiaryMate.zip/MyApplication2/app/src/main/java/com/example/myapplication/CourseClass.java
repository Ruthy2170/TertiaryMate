package com.example.myapplication;

import android.app.Application;

public class CourseClass
{
    private String courseName;
    private String objectId;

    public CourseClass(String courseName) {
    }

        public CourseClass(String courseName, String objectId) {

            this.courseName = courseName;
            this.objectId = objectId;
        }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }
}
