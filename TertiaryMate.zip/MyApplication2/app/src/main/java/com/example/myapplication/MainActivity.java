package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CourseAdapter.ItemClicked
{

    RecyclerView recyclerView;
    RecyclerView.Adapter myAdapter;
    RecyclerView.LayoutManager layoutManager;
    TextView tvCourse;
    EditText etNewCourse;
    Button btnSave;

    ArrayList<CourseClass> courseClasses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCourse = findViewById(R.id.tvCourse);
        etNewCourse = findViewById(R.id.etNewCourse);
        btnSave = findViewById(R.id.btnSave);

        recyclerView = findViewById(R.id.rvCourses);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

       courseClasses = new ArrayList<CourseClass>();



        //String whereClause = "courseName";

        DataQueryBuilder queryBuilder = DataQueryBuilder.create();
        //queryBuilder.setWhereClause(whereClause);
        queryBuilder.setGroupBy("courseName");

        Backendless.Persistence.of(CourseClass.class).find(queryBuilder, new AsyncCallback<List<CourseClass>>() {
            @Override
            public void handleResponse(List<CourseClass> response) {

                myAdapter = new CourseAdapter(MainActivity.this, response);
                recyclerView.setAdapter(myAdapter);

            }

            @Override
            public void handleFault(BackendlessFault fault) {

                Toast.makeText(MainActivity.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

/*
        courseClasses.add(new CourseClass("Information Technology"));
        courseClasses.add(new CourseClass("BED"));
        courseClasses.add(new CourseClass("Human Resources"));
        courseClasses.add(new CourseClass("Geology"));
        courseClasses.add(new CourseClass("Dentist"));
        courseClasses.add(new CourseClass("Marketing Management"));
        courseClasses.add(new CourseClass("Marketing Research"));
        courseClasses.add(new CourseClass("Project Management"));
        courseClasses.add(new CourseClass("Business Administration"));
        courseClasses.add(new CourseClass("Customer Relations"));
        courseClasses.add(new CourseClass("Real Estate"));
        courseClasses.add(new CourseClass("Entrepreneurship"));
        courseClasses.add(new CourseClass("Theater Studies"));
        courseClasses.add(new CourseClass("Accounting"));
        courseClasses.add(new CourseClass("Economics"));
        courseClasses.add(new CourseClass("Computer Science"));
        courseClasses.add(new CourseClass("Graphic Design"));
        courseClasses.add(new CourseClass("Communication"));
        courseClasses.add(new CourseClass("Electrical Engineering"));
        courseClasses.add(new CourseClass("Radiology"));
        courseClasses.add(new CourseClass("Actual Science"));

        myAdapter = new CourseAdapter(this, courseClasses);
       // recyclerView.setAdapter(myAdapter);

        //CourseClass courseClass=new CourseClass();
        //courseClass.setCourseName("Marketing");



        Backendless.Data.of(CourseClass.class).save(courseClass, new AsyncCallback<CourseClass>() {
            @Override
            public void handleResponse(CourseClass response) {

            }

            @Override
            public void handleFault(BackendlessFault fault) {

            }
        });

*/


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etNewCourse.getText().toString().isEmpty() == false) {

                    Backendless.Persistence.save(ApplicationClass.courseClasses.get(1), new AsyncCallback<CourseClass>() {
                        @Override
                        public void handleResponse(CourseClass response) {

                            Toast.makeText(MainActivity.this, "Course successfully saved", Toast.LENGTH_SHORT).show();

                        }


                        @Override
                        public void handleFault(BackendlessFault fault) {

                            Toast.makeText(MainActivity.this, "Error: " + fault.getMessage() , Toast.LENGTH_SHORT).show();

                        }
                    });


                } else
                {


                    Toast.makeText(MainActivity.this, "You did not type anything!", Toast.LENGTH_SHORT).show();

                }

            }

            });
    }

    @Override
    public void onItemClicked(int index) {

        Intent intent = new Intent(MainActivity.this, Universities.class);
        intent.putExtra("index", index);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



    }
}
