package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InstitutionAdapter extends RecyclerView.Adapter<InstitutionAdapter.ViewHolder>
{
    private List<Institution> institutions;

   ItemClicked activity;


    public interface ItemClicked
    {

        void onItemClicked(int index);
    }

    public InstitutionAdapter (Context context, List<Institution> list)
    {
        institutions = list;

        activity = (ItemClicked) context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvUniversity;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            tvUniversity = itemView.findViewById(R.id.tvUniversity);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    activity.onItemClicked(institutions.lastIndexOf((Institution) view.getTag()));

                }
            });
        }
    }


    @NonNull
    @Override
    public InstitutionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items2, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull InstitutionAdapter.ViewHolder holder, int position) {

        holder.itemView.setTag(institutions.get(position));
        holder.tvUniversity.setText(institutions.get(position).getUniversityName());

    }

    @Override
    public int getItemCount() {
        return institutions.size();
    }
}
